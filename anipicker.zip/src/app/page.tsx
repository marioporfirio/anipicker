// src/app/page.tsx
import MainContent from '@/components/MainContent';
import GenreFilter from '@/components/GenreFilter';
import TagFilter from '@/components/TagFilter';
import { fetchTrendingAnime } from '@/lib/anilist';

export default async function HomePage() {
  // A lista inicial que você vê são os animes mais populares
  const initialAnimes = await fetchTrendingAnime();

  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <MainContent 
        initialAnimes={initialAnimes} 
        filtersComponent={
          <>
            <GenreFilter />
            <TagFilter />
          </>
        }
      />
    </div>
  );
}