// src/components/AnimeGrid.tsx
'use client';

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useFilterStore } from '@/store/filterStore';
import { searchAnime, Anime } from '@/lib/anilist';
import { sortOptionTranslations, sidebarLabelTranslations } from '@/lib/translations';
import AnimeCard from '@/components/AnimeCard';
import { useDebounce } from 'use-debounce';

const MIN_YEAR = 1970;
const MAX_YEAR = new Date().getFullYear() + 1;

// CORREÇÃO: Lista completa e correta de ordenações que o botão de inversão afeta.
const invertibleSortOptions = [
  'POPULARITY_DESC', 'SCORE_DESC', 'START_DATE_DESC', 'END_DATE_DESC', 
  'EPISODES_DESC', 'DURATION_DESC', 'ID_DESC', 
  'TITLE_ROMAJI_DESC', 'TITLE_ENGLISH_DESC', 'TITLE_NATIVE_DESC'
];

interface AnimeGridProps {
  initialAnimes: Anime[];
}

export default function AnimeGrid({ initialAnimes }: AnimeGridProps) {
  const { 
    search, yearRange, scoreRange, genres, tags, formats, sources,
    includeTBA, sortBy, statuses, language, sortDirection,
    setSortBy, isSidebarOpen, toggleSortDirection
  } = useFilterStore();
  
  const filters = useMemo(() => ({ search, yearRange, scoreRange, genres, tags, formats, sources, includeTBA, sortBy, statuses, language, sortDirection }), [search, yearRange, scoreRange, genres, tags, formats, sources, includeTBA, sortBy, statuses, language, sortDirection]);
  const [debouncedFilters] = useDebounce(filters, 500);

  const [animes, setAnimes] = useState<Anime[]>(initialAnimes);
  const [isLoading, setIsLoading] = useState(false);
  const [isNextPageLoading, setIsNextPageLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(true);
  
  // Efeito principal para buscar dados
  useEffect(() => {
    const isAnyFilterActive = debouncedFilters.search.length > 0 || debouncedFilters.formats.length > 0 || debouncedFilters.sources.length > 0 || debouncedFilters.statuses.length > 0 || debouncedFilters.includeTBA || debouncedFilters.yearRange[0] > MIN_YEAR || debouncedFilters.yearRange[1] < MAX_YEAR || debouncedFilters.scoreRange[0] > 0 || debouncedFilters.scoreRange[1] < 100 || debouncedFilters.genres.length > 0 || debouncedFilters.tags.length > 0;
    const isDefaultSort = debouncedFilters.sortBy === 'POPULARITY_DESC' && debouncedFilters.sortDirection === 'DESC';
    const isDefaultState = !isAnyFilterActive && isDefaultSort;

    const fetchData = async () => {
      setIsLoading(true);
      setPage(1);
      const results = await searchAnime(debouncedFilters, 1);
      setAnimes(results.animes);
      setHasNextPage(results.hasNextPage);
      setIsLoading(false);
      window.scrollTo(0, 0);
    };

    if (isDefaultState) {
        setAnimes(initialAnimes);
        setPage(1);
        setHasNextPage(true);
        setIsLoading(false);
    } else {
        fetchData();
    }
  }, [debouncedFilters, initialAnimes]);

  const loadMoreAnimes = useCallback(async () => {
    if (isNextPageLoading || !hasNextPage) return;
    setIsNextPageLoading(true); 
    const nextPage = page + 1;
    const results = await searchAnime(debouncedFilters, nextPage);
    setAnimes(prev => [...prev, ...results.animes]); 
    setPage(nextPage);
    setHasNextPage(results.hasNextPage); 
    setIsNextPageLoading(false);
  }, [isNextPageLoading, hasNextPage, page, debouncedFilters]);

  const observer = useRef<IntersectionObserver | null>(null);
  const lastAnimeElementRef = useCallback((node: HTMLDivElement) => {
    if (isLoading || isNextPageLoading) return; 
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => { 
      if (entries[0].isIntersecting && hasNextPage) { 
        loadMoreAnimes(); 
      } 
    });
    if (node) observer.current.observe(node);
  }, [isLoading, isNextPageLoading, hasNextPage, loadMoreAnimes]);
  
  const isAnyFilterActiveForUI = debouncedFilters.search.length > 0 || debouncedFilters.formats.length > 0 || debouncedFilters.sources.length > 0 || debouncedFilters.statuses.length > 0 || debouncedFilters.includeTBA || debouncedFilters.yearRange[0] > MIN_YEAR || debouncedFilters.yearRange[1] < MAX_YEAR || debouncedFilters.scoreRange[0] > 0 || debouncedFilters.scoreRange[1] < 100 || debouncedFilters.genres.length > 0 || debouncedFilters.tags.length > 0;
  const currentTitle = isAnyFilterActiveForUI ? (language === 'pt' ? 'Resultados da Busca' : 'Search Results') : (language === 'pt' ? 'Animes Populares' : 'Popular Anime');
  
  const isSearchTextActive = debouncedFilters.search.length > 0;
  const finalSortByForDisplay = isSearchTextActive ? 'RELEVANCE' : sortBy;
  const isCurrentSortInvertible = invertibleSortOptions.includes(sortBy);
  
  if (isLoading) {
    return <div className="flex justify-center items-center h-96"><p className="text-text-secondary text-lg animate-pulse">Buscando animes...</p></div>;
  }

  return (
    <section className="px-4">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
          <h2 className="text-2xl font-semibold border-l-4 border-primary pl-3">{currentTitle}</h2>
          <div className="flex items-center gap-2">
              <label htmlFor="sort-by" className="text-sm text-text-secondary">{sidebarLabelTranslations[language]?.sortByLabel || sidebarLabelTranslations.pt.sortByLabel}</label>
              <select 
                id="sort-by" 
                value={finalSortByForDisplay} 
                onChange={(e) => setSortBy(e.target.value)} 
                disabled={isSearchTextActive}
                className="bg-surface border border-gray-600 rounded-md px-3 py-1.5 text-sm text-text-main focus:ring-1 focus:ring-primary focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {Object.entries(sortOptionTranslations).map(([value, translations]) => (
                  <option key={value} value={value}>
                    {translations?.[language] || translations?.['pt'] || value}
                  </option>
                ))}
              </select>
              <button 
                onClick={toggleSortDirection} 
                disabled={isSearchTextActive || !isCurrentSortInvertible}
                title={language === 'pt' ? 'Inverter Ordem' : 'Invert Order'}
                className="p-1.5 bg-surface border border-gray-600 rounded-md text-text-secondary disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-700 hover:text-primary"
              >
                {sortDirection === 'DESC' ? 
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M19 12l-7 7-7-7"/></svg> :
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
                }
              </button>
          </div>
        </div>
        
        <div className="relative">
            {animes.length > 0 ? (
                <div className={`grid grid-cols-2 gap-4 transition-all duration-300 sm:grid-cols-3 ${isSidebarOpen ? 'lg:grid-cols-3 xl:grid-cols-4' : 'lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6'}`}>
                {animes.map((anime, index) => {
                    const isLastElement = animes.length === index + 1;
                    const props = { anime: anime, priority: index < 10 };

                    if (isLastElement && hasNextPage) {
                      return <div ref={lastAnimeElementRef} key={`${anime.id}-${index}`}><AnimeCard {...props} /></div>;
                    }
                    return <AnimeCard key={`${anime.id}-${index}`} {...props} />;
                })}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center h-96 text-center"><p className="text-xl text-text-secondary">Nenhum anime encontrado.</p><p className="text-md text-gray-500 mt-2">Tente ajustar seus filtros.</p></div>
            )}
        </div>

        {isNextPageLoading && <div className="flex justify-center items-center mt-8 h-16"><p className="text-text-secondary animate-pulse">Carregando mais...</p></div>}
        {!hasNextPage && animes.length > 0 && <div className="text-center mt-8 text-text-secondary"><p>Você chegou ao fim dos resultados.</p></div>}
    </section>
  );
}